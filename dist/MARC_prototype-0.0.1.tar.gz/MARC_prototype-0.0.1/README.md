# NYAS-COVID19-Challenge

MARC - Monitor and Analyze Risk Covid19

Created for the NYAS Combating COVID19 project

Team:

Rahul P.

Aria M.

Viveka C.

Fatima T.

Code by: Rahul P.

For modules, go to tools/

for full documentation, go to docs/

For sample implementations, go to docs/samples

For installation help, go to docs/installation